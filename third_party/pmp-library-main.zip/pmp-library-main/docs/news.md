# News {#news}

- @subpage version-3-0-released-2023-08-24 - Aug 24, 2023
- @subpage version-2-0-1-released-2022-08-26 - Aug 26, 2022
- @subpage version-2-0-released-2022-08-14 - Aug 14, 2022
- @subpage pmp-at-sgp-2020-07-06 - Jul 06, 2020
- @subpage version-1-2-1-released-2020-05-10 - May 10, 2020
- @subpage version-1-2-released-2020-03-15 - March 15, 2020
- @subpage interactive-html-slides-2019-06-02 - June 2, 2019
- @subpage version-1-1-released-2019-05-30 - May 30, 2019
- @subpage version-one-released-2019-02-18 - Feb 18, 2019
- @subpage license-changed-2019-02-16 - Feb 16, 2019

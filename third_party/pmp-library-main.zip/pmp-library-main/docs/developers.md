# Developers {#developers}

- @subpage contributing -- instructions for submitting contributions
- @subpage codingstyle -- the coding style we follow around here

# Advanced {#advanced}

- @subpage eigen -- interfacing with Eigen
- @subpage emscripten -- building JavaScript apps using emscripten
